package com.example.assignment.views

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment.R

class MainActivity : AppCompatActivity() {
    var button: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.btn_load);

        button?.setOnClickListener(View.OnClickListener {
            Toast.makeText(
                this@MainActivity,
                "fetch data kotlin ",
                Toast.LENGTH_SHORT
            ).show()


            val intent = Intent(this@MainActivity, LoadActivity::class.java)
            startActivity(intent)
        })
    }
}