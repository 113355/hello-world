package com.example.assignment.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.R
import com.example.assignment.views.YoutubeActivity
import com.example.assignment.model.VideoItems

internal class VideosAdapter(private val context:Context, private var videoItems: List<VideoItems>) :
        RecyclerView.Adapter<VideosAdapter.MyViewHolder>() {


    internal inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        var title: TextView = view.findViewById(R.id.title)
        var year: TextView = view.findViewById(R.id.year)
        var genre: TextView = view.findViewById(R.id.genre)
    }


    @NonNull
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.video_list, parent, false)
        return MyViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val video = videoItems[position]
        holder.title.text = video.title
        holder.genre.text = video.id
        holder.year.text =  video.viewCount

        holder.itemView.setOnClickListener{
            Log.e("*Click", holder.genre.text.toString())
            val intent : Intent = Intent(context, YoutubeActivity::class.java)
            intent.putExtra("video_id", holder.genre.text.toString())
            context.startActivity(intent)
        }
    }
    override fun getItemCount(): Int {
        return videoItems.size
    }
}