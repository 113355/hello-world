package com.example.assignment.testagain

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)