package com.example.assignment.testagain

data class Maxres(
    val height: Int,
    val url: String,
    val width: Int
)