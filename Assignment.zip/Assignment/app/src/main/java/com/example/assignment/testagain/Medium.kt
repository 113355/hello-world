package com.example.assignment.testagain

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)