package com.example.assignment.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.assignment.model.ServicesGetterSetter
import com.example.assignment.repository.MainActivityRepository
import com.example.assignment.testagain.YoutubeVideos

class MainActivityViewModel : ViewModel() {

    var servicesLiveData: MutableLiveData<YoutubeVideos>? = null

    fun getUser() : MutableLiveData<YoutubeVideos>{
        servicesLiveData = MainActivityRepository.getServicesApiCall()

        return servicesLiveData as MutableLiveData<YoutubeVideos>
    }

}