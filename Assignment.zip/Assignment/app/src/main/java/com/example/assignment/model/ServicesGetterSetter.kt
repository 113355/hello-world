package com.example.assignment.model

data class ServicesGetterSetter (
    val message: String? = null
)