package com.example.assignment.testagain

data class Localized(
    val description: String,
    val title: String
)