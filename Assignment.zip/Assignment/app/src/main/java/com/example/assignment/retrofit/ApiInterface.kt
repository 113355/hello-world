package com.example.assignment.retrofit

import com.example.assignment.model.ServicesGetterSetter
import com.example.assignment.testagain.YoutubeVideos
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface ApiInterface {
    @GET("/youtube/v3/videos")
    fun getServices(
                    @Query("key") apiKey: String?,
                    @Query("part") videoPart: String?,
                    @Query("chart") videoChart: String?,
                    @Query("regionCode") regionCode: String,
                    @Query("maxResults") maxResults: Int): Call<YoutubeVideos>
}
