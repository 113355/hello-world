package com.example.assignment.testagain

class ContentRating(
)