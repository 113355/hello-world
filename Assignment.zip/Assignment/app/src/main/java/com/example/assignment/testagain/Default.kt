package com.example.assignment.testagain

data class Default(
    val height: Int,
    val url: String,
    val width: Int
)