package com.example.assignment.testagain

data class Statistics(
    val commentCount: String,
    val dislikeCount: String,
    val favoriteCount: String,
    val likeCount: String,
    val viewCount: String
)