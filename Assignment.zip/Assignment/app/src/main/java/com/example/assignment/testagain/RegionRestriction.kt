package com.example.assignment.testagain

data class RegionRestriction(
    val blocked: List<String>
)