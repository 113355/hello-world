package com.example.assignment.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.assignment.retrofit.RetrofitClient
import com.example.assignment.testagain.YoutubeVideos
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object MainActivityRepository {

    val serviceSetterGetter = MutableLiveData<YoutubeVideos>()

    fun getServicesApiCall(): MutableLiveData<YoutubeVideos> {
        val chart: String = "snippet,contentDetails,statistics"

        val call = RetrofitClient.apiInterface.getServices("AIzaSyB7xsOH8NG3cGcsOhSKWmvDMs8GlXOKNGA",
                 chart,"mostPopular","US", 10)

        call.enqueue(object : Callback<YoutubeVideos> {
            override fun onFailure(call: Call<YoutubeVideos>, t: Throwable) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", t.message.toString())
            }

            override fun onResponse(call: Call<YoutubeVideos>, response: Response<YoutubeVideos>) {
                if(response.isSuccessful){
                    response.body()?.let {
                        Log.e("**", "$it")



                        serviceSetterGetter.postValue(response.body())
                    }
                }
            }

        })

        return serviceSetterGetter
    }
}