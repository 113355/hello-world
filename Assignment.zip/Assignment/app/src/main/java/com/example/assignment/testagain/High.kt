package com.example.assignment.testagain

data class High(
    val height: Int,
    val url: String,
    val width: Int
)