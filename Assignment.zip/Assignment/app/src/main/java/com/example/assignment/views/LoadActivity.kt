package com.example.assignment.views

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.R
import com.example.assignment.adapter.VideosAdapter
import com.example.assignment.model.VideoItems
import com.example.assignment.testagain.YoutubeVideos
import com.example.assignment.viewmodel.MainActivityViewModel

class LoadActivity : AppCompatActivity() {
    lateinit var context: Context
    var textMessage:TextView? = null

    lateinit var mainActivityViewModel: MainActivityViewModel
    private val videoList = ArrayList<YoutubeVideos>()
    private var itemList = ArrayList<VideoItems>()

    private lateinit var videoAdapter: VideosAdapter

    var servicesLiveData: MutableLiveData<YoutubeVideos>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_load)
        itemList.add(VideoItems("DUMMY","DUUMY","DUMMY"))
         textMessage = findViewById<TextView>(R.id.textMessage)
        val rView : RecyclerView = findViewById(R.id.recycleView)
        context = this@LoadActivity

        videoAdapter = VideosAdapter(context,itemList)
        val layoutManager = LinearLayoutManager(applicationContext)
        rView.layoutManager = layoutManager
        rView.itemAnimator = DefaultItemAnimator()
        rView.adapter = videoAdapter

        mainActivityViewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)

            mainActivityViewModel.getUser()!!.observe(this, Observer { serviceSetterGetter ->

                    serviceSetterGetter?.let {
                        videoList.add(serviceSetterGetter)
                        var items = serviceSetterGetter.items
                       // val iterator = items.listIterator()

                        for (i in 0..items.size-1){
                           // Log.e("*CHECK ",items[i].id)
                            var videoItem = VideoItems(items[i].snippet.title, items[i].id,
                                items[i].statistics.viewCount)
                            itemList.add(videoItem)
                        }
                        videoAdapter.notifyDataSetChanged()

                      /*  while (iterator.hasNext()){
                            Log.e("*iterator", iterator.next().snippet.title +"   "+
                                    iterator.next().id+ " " +iterator.next().statistics.viewCount+"")
                               VideoItems(iterator.next().snippet.title, iterator.next().id,
                                   iterator.next().statistics.toString())
                        }*/

                       // videoAdapter.notifyDataSetChanged()

                        //Log.e("**LIVE", "$it")

                    }
    })
    }
}