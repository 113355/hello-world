package com.example.assignment.model

import com.example.assignment.testagain.Item
import com.example.assignment.testagain.PageInfo

data class VideoItems(
        val title: String,
        val id: String,
        val viewCount: String
)