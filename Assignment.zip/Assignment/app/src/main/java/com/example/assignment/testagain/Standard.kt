package com.example.assignment.testagain

data class Standard(
    val height: Int,
    val url: String,
    val width: Int
)